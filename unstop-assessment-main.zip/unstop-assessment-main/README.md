# unstop-assessment
The train coach has 80 seats: 10 rows of 7 and 1 row of 3. Users can book up to 7 seats at once, prioritizing seats in the same row. If unavailable, nearby seats are allocated. Reservations continue until all seats are full. No login is needed; the focus is on simple, efficient seat booking.
